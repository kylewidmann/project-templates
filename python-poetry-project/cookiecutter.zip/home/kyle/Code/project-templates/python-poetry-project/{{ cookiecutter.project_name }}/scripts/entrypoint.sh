#!/usr/bin/env bash
set -ex
exec $@