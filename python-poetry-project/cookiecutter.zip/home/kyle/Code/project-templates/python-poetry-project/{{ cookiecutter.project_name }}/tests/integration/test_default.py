def test_default():
    assert True